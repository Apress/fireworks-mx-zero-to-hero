//THIS WRITES THE CURRENT DATE INTO THE PAGE
document.write("<span class='date'>")
var mydate=new Date()
var year=mydate.getYear()
if (year<2000)
year += (year < 1900) ? 1900 : 0
var day=mydate.getDay()
var month=mydate.getMonth()
var daym=mydate.getDate()
if (daym<10)
daym="0"+daym
var montharray=new Array("1","2","3","4","5","6","7","8","9","10","11","12")
document.write(+montharray[month]+"/"+daym+"/"+year+"&nbsp; &nbsp;")
document.write("</span>")

